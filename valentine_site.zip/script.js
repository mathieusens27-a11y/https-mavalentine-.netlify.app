const noBtn = document.getElementById("noBtn");
const music = document.getElementById("bgMusic");

const phrases = ["Trop tard 😏", "Essaie encore 😌", "Presque 😂", "Nope 💨", "Impossible 💘"];

document.addEventListener("mousemove", (e) => {
    const rect = noBtn.getBoundingClientRect();
    const distance = Math.hypot(
        e.clientX - (rect.left + rect.width / 2),
        e.clientY - (rect.top + rect.height / 2)
    );

    if (distance < 150) {
        const x = Math.random() * (window.innerWidth - noBtn.offsetWidth);
        const y = Math.random() * (window.innerHeight - noBtn.offsetHeight);

        noBtn.style.position = "absolute";
        noBtn.style.left = x + "px";
        noBtn.style.top = y + "px";
        noBtn.innerText = phrases[Math.floor(Math.random() * phrases.length)];
    }
});

document.addEventListener("click", () => {
    if (music.paused) music.play();
});
